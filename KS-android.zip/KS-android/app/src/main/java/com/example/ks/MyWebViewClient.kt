package com.example.ks

import android.webkit.WebView
import android.webkit.WebViewClient

class MyWebViewClient : WebViewClient() {
    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
        if (url != null && (url.contains("page1.php") || url.contains("page2.php") || url.contains("page3.php") || url.contains("page4.php"))) {
            // "page1.php", "page2.php", "page3.php", "page4.php"를 포함하는 URL이 감지되면
            return false // false로 설정하여 WebView 내부에서 URL을 처리하도록 합니다.
        }

        // WebView 외부에서 URL을 처리하도록 설정합니다.
        return false
    }

}
