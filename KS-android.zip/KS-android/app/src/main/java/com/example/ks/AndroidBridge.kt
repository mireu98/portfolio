package com.example.ks

import android.content.Context
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.io.BufferedWriter
import java.io.IOException
import java.io.OutputStreamWriter

class AndroidBridge(private val context: Context, private val wv1: WebView, private val wv2: WebView, private val wv3: WebView, private val wv4: WebView) {
    @JavascriptInterface
    fun postMessage(ip: String, select: Int) {
        // POST 데이터를 Android 앱에서 수신
        Log.d("Received POST Data", "IP: $ip, Select: $select")
        // POST 데이터로 url.txt 파일 업데이트
        updateUrlTxt(ip,select)

        // WebView 변경
        showWebView(ip,select)
    }

    @JavascriptInterface
    fun getUrlValue(): String {
        // 여기에서 url.txt 파일의 값을 읽어서 반환
        return readUrlTxt()
    }

    private fun readUrlTxt(): String {
        try {
            // url.txt 파일을 읽어오기
            val fileInputStream = context.openFileInput("url.txt")
            val bufferedReader = fileInputStream.bufferedReader()
            val text = bufferedReader.readLine()
            fileInputStream.close()
            return text
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return "58.229.176.179"
    }


    private fun showWebView(ip: String,select: Int) {
        val baseUrl = "http://$ip/KS/page"
        Log.d("tttt","ttttt")
        val urlToLoad = when (select) {
            1 -> "$baseUrl" + "1.php"
            3 -> "$baseUrl" + "3.php"
            4 -> "$baseUrl" + "4.php"
            else -> {
                Log.e("Android App", "Invalid select value")
                return
            }
        }

        wv1.post {
            wv1.loadUrl(urlToLoad)
        }
        wv2.post {
            wv2.loadUrl(urlToLoad)
        }
        wv3.post {
            wv3.loadUrl(urlToLoad)
        }
        wv4.post {
            wv4.loadUrl(urlToLoad)
        }
    }

    private fun updateUrlTxt(ip: String, select: Int) {
        try {
            // url.txt 파일을 쓰기 모드로 열기
            val fileName = "url.txt"
            val fileOutputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE)
            val writer = BufferedWriter(OutputStreamWriter(fileOutputStream))

            // POST 데이터로 파일 업데이트
            writer.write(ip)
            writer.newLine()
            writer.write(select.toString())
            writer.close()


        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}
