package com.example.ks

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Parcel
import android.util.Base64
import android.view.View
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.example.ks.databinding.ActivityMainBinding
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var WV1: WebView
    private lateinit var WV2: WebView
    private lateinit var WV3: WebView
    private lateinit var WV4: WebView
    private var selectedPage: Int = 1
    private var url: String? = null
    private lateinit var androidBridge: AndroidBridge
    override fun onPause() {
        super.onPause()

        val sharedPrefs = getSharedPreferences("MyPreferences", Context.MODE_PRIVATE)
        val editor = sharedPrefs.edit()

        editor.putInt("selectedPage", selectedPage)

        val bundle1 = Bundle()
        WV1.saveState(bundle1)
        val webView1StateJSON = bundleToJson(bundle1) // Bundle을 JSON 문자열로 변환
        editor.putString("WV1State", webView1StateJSON)

        val bundle2 = Bundle()
        WV2.saveState(bundle2)
        val webView2StateJSON = bundleToJson(bundle2)
        editor.putString("WV2State", webView2StateJSON)

        val bundle3 = Bundle()
        WV3.saveState(bundle3)
        val webView3StateJSON = bundleToJson(bundle3)
        editor.putString("WV3State", webView3StateJSON)


        
        val bundle4 = Bundle()
        WV4.saveState(bundle4)
        val webView4StateJSON = bundleToJson(bundle4)
        editor.putString("WV4State", webView4StateJSON)

        editor.apply()
    }

    // Bundle을 JSON 문자열로 변환
    private fun bundleToJson(bundle: Bundle): String {
        val jsonObject = JSONObject()
        for (key in bundle.keySet()) {
            val value = bundle.get(key)
            try {
                jsonObject.put(key, value)
            } catch (e: JSONException) {
                // JSON 변환 중 오류 발생
                e.printStackTrace()
            }
        }
        return jsonObject.toString()
    }
    private fun readUrlTxt(): String {
        try {
            // url.txt 파일을 읽어오기
            val fileInputStream = openFileInput("url.txt")
            val bufferedReader = fileInputStream.bufferedReader()
            val text = bufferedReader.readLine()
            fileInputStream.close()
            return text
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return "58.229.176.179"
    }
    private fun getSelectFromUrlTxt(): Int {
        try {
            // url.txt 파일을 읽어오기
            val fileInputStream = openFileInput("url.txt")
            val bufferedReader = fileInputStream.bufferedReader()

            // 첫 번째 줄은 읽고 버림 (ip 값)
            bufferedReader.readLine()

            // 두 번째 줄은 select 값을 읽어와 Int로 변환
            val select = bufferedReader.readLine()?.toIntOrNull() ?: 1

            fileInputStream.close()
            return select
        } catch (e: IOException) {
            e.printStackTrace()
        }

        // 읽기가 실패하면 기본값으로 0을 반환하거나 실패를 나타내는 다른 값을 반환할 수 있습니다.
        return 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WV1 = binding.WV1
        WV2 = binding.WV2
        WV3 = binding.WV3
        WV4 = binding.WV4
        url = readUrlTxt()

        selectedPage = getSelectFromUrlTxt()

        WV1.settings.javaScriptEnabled = true
        WV2.settings.javaScriptEnabled = true
        WV3.settings.javaScriptEnabled = true
        WV4.settings.javaScriptEnabled = true
        androidBridge = AndroidBridge(this, WV1, WV2, WV3, WV4)
        WV1.addJavascriptInterface(androidBridge, "AndroidBridge")
        WV2.addJavascriptInterface(androidBridge, "AndroidBridge")
        WV3.addJavascriptInterface(androidBridge, "AndroidBridge")
        WV4.addJavascriptInterface(androidBridge, "AndroidBridge")

        WV1.webViewClient = MyWebViewClient()
        WV2.webViewClient = MyWebViewClient()
        WV3.webViewClient = MyWebViewClient()
        WV4.webViewClient = MyWebViewClient()

        if (savedInstanceState != null) {
            selectedPage = savedInstanceState.getInt("selectedPage")

            val webView1State = savedInstanceState.getBundle("WV1State")
            if (webView1State != null) {
                WV1.restoreState(webView1State)
            }

            val webView2State = savedInstanceState.getBundle("WV2State")
            if (webView2State != null) {
                WV2.restoreState(webView2State)
            }

            val webView3State = savedInstanceState.getBundle("WV3State")
            if (webView3State != null) {
                WV3.restoreState(webView3State)
            }

            val webView4State = savedInstanceState.getBundle("WV4State")
            if (webView4State != null) {
                WV4.restoreState(webView4State)
            }
        } else {
            loadWebView(selectedPage)
        }

    }

    // Bundle을 문자열로 직렬화하는 함수
    private fun serializeBundle(bundle: Bundle): String {
        val parcel = Parcel.obtain()
        bundle.writeToParcel(parcel, 0)
        val bytes = parcel.marshall()
        parcel.recycle()
        return Base64.encodeToString(bytes, Base64.NO_PADDING)
    }

    private fun loadWebView(selectedPage: Int) {
        val baseUrl = "http://$url/KS/page"
        when (selectedPage) {
            1 -> {
                WV1.visibility = View.VISIBLE
                WV1.loadUrl("$baseUrl" + "1.php")
                WV2.visibility = View.GONE
                WV3.visibility = View.GONE
                WV4.visibility = View.GONE
            }
            2 -> {
                WV1.visibility = View.GONE
                WV2.visibility = View.VISIBLE
                WV2.loadUrl("$baseUrl" + "2.php")
                WV3.visibility = View.GONE
                WV4.visibility = View.GONE
            }
            3 -> {
                WV1.visibility = View.GONE
                WV2.visibility = View.GONE
                WV3.visibility = View.VISIBLE
                WV3.loadUrl("$baseUrl" + "3.php")
                WV4.visibility = View.GONE
            }
            4 -> {
                WV1.visibility = View.GONE
                WV2.visibility = View.GONE
                WV3.visibility = View.GONE
                WV4.visibility = View.VISIBLE
                WV4.loadUrl("$baseUrl" + "4.php")
            }
            else -> {

            }
        }
    }
}
